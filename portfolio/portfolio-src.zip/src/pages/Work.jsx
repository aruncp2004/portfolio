import { useState } from 'react';
import { projects } from '../data/projects';
import ProjectCard from '../components/shared/ProjectCard';

const filters = ['All', 'Website Concept', 'Professional Experience'];

export default function Work() {
  const [active, setActive] = useState('All');

  const filtered = projects.filter((p) => {
    if (active === 'All') return true;
    if (active === 'Website Concept') return p.classification === 'concept';
    if (active === 'Professional Experience') return p.classification === 'experience';
    if (active === 'Client Project') return p.classification === 'client';
    return true;
  });

  return (
    <main className="pt-32 pb-24">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="mb-14">
          <p className="text-xs font-semibold text-teal-400 uppercase tracking-widest mb-3">Portfolio</p>
          <h1 className="font-display font-bold text-4xl md:text-5xl text-white mb-4">
            Projects & Work
          </h1>
          <p className="text-white/45 text-base max-w-xl">
            Website concepts, professional experience and client work in healthcare and business web development.
          </p>
        </div>

        {/* Filter tabs */}
        <div className="flex flex-wrap gap-2 mb-10">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setActive(f)}
              className={`text-sm font-medium px-4 py-2 rounded-full transition-all ${
                active === f
                  ? 'bg-teal-400/15 text-teal-400 border border-teal-400/30'
                  : 'glass text-white/50 hover:text-white border border-white/[0.08]'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
          {filtered.map((project, i) => (
            <ProjectCard key={project.id} project={project} index={i} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20 text-white/30">
            No projects in this category yet.
          </div>
        )}
      </div>
    </main>
  );
}
