import { useState } from 'react';
import { MessageCircle, Phone, Mail, Send, CheckCircle } from 'lucide-react';

const contactMethods = [
  {
    icon: MessageCircle,
    label: 'WhatsApp',
    value: '+91 94980 96306',
    href: 'https://wa.me/919498096306',
    description: 'Fastest response — usually within a few hours.',
    accent: '#25D366',
  },
  {
    icon: Phone,
    label: 'Phone',
    value: '+91 94980 96306',
    href: 'tel:+919498096306',
    description: 'Available Mon–Sat, 9am–7pm IST.',
    accent: '#00d4c8',
  },
  {
    icon: Mail,
    label: 'Email',
    value: 'hello@arunkumar.dev',
    href: 'mailto:hello@arunkumar.dev',
    description: 'For detailed enquiries and project briefs.',
    accent: '#7c6fff',
  },
];

export default function Contact() {
  const [form, setForm] = useState({ name: '', clinic: '', phone: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    // Simulate submission — replace with real API/form handler
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 1200);
  };

  return (
    <main className="pt-32 pb-24">
      <div className="max-w-5xl mx-auto px-6">
        {/* Header */}
        <div className="mb-14 text-center">
          <p className="text-xs font-semibold text-teal-400 uppercase tracking-widest mb-3">
            Get In Touch
          </p>
          <h1 className="font-display font-bold text-4xl md:text-5xl text-white mb-4">
            Let's build your clinic's<br />
            <span className="gradient-text">website together</span>
          </h1>
          <p className="text-white/45 text-base max-w-lg mx-auto">
            Start with a free website demo — no commitment, no payment required. Just reach out and I'll take it from there.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Contact methods */}
          <div className="lg:col-span-2 space-y-4">
            {contactMethods.map((m) => {
              const Icon = m.icon;
              return (
                <a
                  key={m.label}
                  href={m.href}
                  target={m.label === 'WhatsApp' ? '_blank' : undefined}
                  rel="noopener noreferrer"
                  className="glass glass-hover rounded-2xl p-5 flex gap-4 items-start block"
                >
                  <div
                    className="shrink-0 w-11 h-11 rounded-xl flex items-center justify-center"
                    style={{ background: `${m.accent}15`, border: `1px solid ${m.accent}25` }}
                  >
                    <Icon size={20} style={{ color: m.accent }} />
                  </div>
                  <div>
                    <p className="text-xs text-white/30 uppercase tracking-widest mb-0.5">{m.label}</p>
                    <p className="font-display font-semibold text-white text-sm mb-1">{m.value}</p>
                    <p className="text-xs text-white/40">{m.description}</p>
                  </div>
                </a>
              );
            })}
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            <div className="glass rounded-2xl p-7 md:p-9">
              {submitted ? (
                <div className="text-center py-10">
                  <div className="w-16 h-16 rounded-full bg-teal-400/10 border border-teal-400/20 flex items-center justify-center mx-auto mb-5">
                    <CheckCircle size={32} className="text-teal-400" />
                  </div>
                  <h3 className="font-display font-bold text-white text-xl mb-2">Message Sent</h3>
                  <p className="text-white/45 text-sm">
                    Thanks for reaching out. I'll get back to you within 24 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-xs text-white/40 mb-2 font-medium">Your Name *</label>
                      <input
                        type="text"
                        name="name"
                        required
                        value={form.name}
                        onChange={handleChange}
                        placeholder="Dr. Ramesh Kumar"
                        className="w-full bg-white/[0.04] border border-white/[0.08] rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-teal-400/40 focus:bg-white/[0.06] transition-all"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-white/40 mb-2 font-medium">Clinic / Business Name</label>
                      <input
                        type="text"
                        name="clinic"
                        value={form.clinic}
                        onChange={handleChange}
                        placeholder="Sunshine Dental Clinic"
                        className="w-full bg-white/[0.04] border border-white/[0.08] rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-teal-400/40 focus:bg-white/[0.06] transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-white/40 mb-2 font-medium">Phone / WhatsApp *</label>
                    <input
                      type="tel"
                      name="phone"
                      required
                      value={form.phone}
                      onChange={handleChange}
                      placeholder="+91 98765 43210"
                      className="w-full bg-white/[0.04] border border-white/[0.08] rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-teal-400/40 focus:bg-white/[0.06] transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-white/40 mb-2 font-medium">Tell me about your project</label>
                    <textarea
                      name="message"
                      rows={4}
                      value={form.message}
                      onChange={handleChange}
                      placeholder="I run a dental clinic in Chennai and I'm looking for a new website..."
                      className="w-full bg-white/[0.04] border border-white/[0.08] rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 focus:outline-none focus:border-teal-400/40 focus:bg-white/[0.06] transition-all resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="btn-primary w-full justify-center py-3.5 disabled:opacity-60 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <span>Sending...</span>
                    ) : (
                      <>
                        <span>Send Message</span>
                        <Send size={16} />
                      </>
                    )}
                  </button>

                  <p className="text-xs text-white/25 text-center">
                    Your information is used only to respond to your enquiry.
                  </p>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
