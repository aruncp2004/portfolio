import { Link } from 'react-router-dom';
import { ArrowRight, MapPin, Code2, Heart } from 'lucide-react';

const skills = [
  'React', 'JavaScript', 'HTML & CSS', 'Tailwind CSS',
  'Node.js', 'Responsive Design', 'Google Analytics', 'SEO Basics',
  'WhatsApp Integration', 'Git & GitHub', 'Vercel', 'cPanel',
];

export default function About() {
  return (
    <main className="pt-32 pb-24">
      <div className="max-w-5xl mx-auto px-6">
        {/* Header */}
        <div className="mb-16">
          <p className="text-xs font-semibold text-teal-400 uppercase tracking-widest mb-4">About</p>
          <h1 className="font-display font-bold text-4xl md:text-5xl text-white mb-6 leading-tight">
            Hi, I'm Arun Kumar —<br />
            <span className="gradient-text">web developer</span> based in Chennai.
          </h1>
          <div className="flex items-center gap-2 text-white/40 text-sm mb-8">
            <MapPin size={14} className="text-teal-400" />
            Chennai, Tamil Nadu, India
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10">
          {/* Bio */}
          <div className="lg:col-span-3 space-y-5">
            <div className="glass rounded-2xl p-7">
              <div className="flex items-center gap-2 mb-4">
                <Code2 size={18} className="text-teal-400" />
                <span className="text-xs font-semibold text-white/40 uppercase tracking-widest">What I Do</span>
              </div>
              <p className="text-white/60 text-base leading-relaxed">
                I build modern, responsive websites for clinics, healthcare businesses and local
                companies. My focus is creating websites that are professionally designed,
                fast, mobile-friendly and built to help businesses build trust with their customers.
              </p>
            </div>

            <div className="glass rounded-2xl p-7">
              <div className="flex items-center gap-2 mb-4">
                <Heart size={18} className="text-violet-400" />
                <span className="text-xs font-semibold text-white/40 uppercase tracking-widest">My Approach</span>
              </div>
              <p className="text-white/60 text-base leading-relaxed">
                I believe a great website starts with understanding the business — the services,
                the patients and what matters most to them. I create a personalised demo before any
                commitment, so you see exactly what you're getting before we start.
              </p>
            </div>

            <div className="glass rounded-2xl p-7">
              <p className="text-xs font-semibold text-white/30 uppercase tracking-widest mb-4">Skills & Tools</p>
              <div className="flex flex-wrap gap-2">
                {skills.map((s) => (
                  <span
                    key={s}
                    className="text-sm px-3 py-1.5 rounded-full bg-white/[0.05] text-white/50 border border-white/[0.07]"
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-2 space-y-5">
            {/* Avatar placeholder */}
            <div
              className="glass rounded-2xl h-56 flex items-center justify-center overflow-hidden relative"
              style={{
                background: 'linear-gradient(135deg, rgba(0,212,200,0.08) 0%, rgba(124,111,255,0.08) 100%)',
              }}
            >
              <div
                className="absolute inset-0"
                style={{
                  backgroundImage: `radial-gradient(circle at 40% 40%, rgba(0,212,200,0.15) 0%, transparent 60%),
                                    radial-gradient(circle at 70% 70%, rgba(124,111,255,0.12) 0%, transparent 50%)`,
                }}
              />
              <span className="relative z-10 font-display font-bold text-5xl gradient-text">AK</span>
            </div>

            {/* Quick facts */}
            <div className="glass rounded-2xl p-6 space-y-4">
              {[
                { label: 'Based In', value: 'Chennai, India' },
                { label: 'Focus', value: 'Healthcare Websites' },
                { label: 'Availability', value: 'Open to projects' },
                { label: 'Languages', value: 'English, Tamil' },
              ].map((f) => (
                <div key={f.label} className="flex justify-between items-center text-sm border-b border-white/[0.04] pb-3 last:border-0 last:pb-0">
                  <span className="text-white/35">{f.label}</span>
                  <span className="text-white/70 font-medium">{f.value}</span>
                </div>
              ))}
            </div>

            <Link to="/contact" className="btn-primary w-full justify-center py-3.5">
              <span>Work With Me</span>
              <ArrowRight size={17} />
            </Link>
          </div>
        </div>
      </div>
    </main>
  );
}
