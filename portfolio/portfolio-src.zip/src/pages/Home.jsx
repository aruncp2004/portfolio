import Hero from '../components/home/Hero';
import SelectedWork from '../components/home/SelectedWork';
import Problems from '../components/home/Problems';
import Services from '../components/home/Services';
import WhyMe from '../components/home/WhyMe';
import Process from '../components/home/Process';
import Experience from '../components/home/Experience';
import Pricing from '../components/home/Pricing';
import FinalCTA from '../components/home/FinalCTA';

export default function Home() {
  return (
    <>
      <Hero />
      <div className="gradient-divider" />
      <SelectedWork />
      <div className="gradient-divider" />
      <Problems />
      <div className="gradient-divider" />
      <Services />
      <div className="gradient-divider" />
      <WhyMe />
      <div className="gradient-divider" />
      <Process />
      <div className="gradient-divider" />
      <Experience />
      <div className="gradient-divider" />
      <Pricing />
      <div className="gradient-divider" />
      <FinalCTA />
    </>
  );
}
