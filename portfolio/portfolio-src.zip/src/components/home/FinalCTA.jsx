import { Link } from 'react-router-dom';
import { ArrowRight, MessageCircle } from 'lucide-react';
import { useScrollReveal } from '../../hooks/useScrollReveal';

export default function FinalCTA() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section className="section-pad">
      <div className="max-w-6xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <div
            className="relative rounded-3xl p-10 md:p-16 text-center overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, rgba(10,10,15,0.9) 0%, rgba(20,18,35,0.9) 100%)',
              border: '1px solid rgba(255,255,255,0.08)',
            }}
          >
            {/* Background orbs */}
            <div
              className="absolute top-0 left-1/4 w-64 h-64 rounded-full pointer-events-none animate-orb"
              style={{
                background: 'radial-gradient(circle, rgba(0,212,200,0.1) 0%, transparent 70%)',
                filter: 'blur(40px)',
              }}
            />
            <div
              className="absolute bottom-0 right-1/4 w-64 h-64 rounded-full pointer-events-none animate-orb-reverse"
              style={{
                background: 'radial-gradient(circle, rgba(124,111,255,0.1) 0%, transparent 70%)',
                filter: 'blur(40px)',
              }}
            />

            <div className="relative z-10">
              <p className="text-xs font-semibold text-teal-400 uppercase tracking-widest mb-4">
                Let's Work Together
              </p>
              <h2 className="font-display font-bold text-3xl md:text-5xl text-white leading-tight mb-5">
                Ready to give your clinic<br className="hidden sm:block" />
                <span className="gradient-text"> a better website?</span>
              </h2>
              <p className="text-white/45 text-base md:text-lg max-w-xl mx-auto mb-10">
                Get a free, personalised website demo for your clinic — no commitment, no payment required.
              </p>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link to="/contact" className="btn-primary text-base px-8 py-3.5">
                  <span>Get a Free Website Demo</span>
                  <ArrowRight size={18} />
                </Link>
                <a
                  href="https://wa.me/919498096306"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-ghost text-base px-8 py-3.5"
                >
                  <MessageCircle size={18} />
                  Chat on WhatsApp
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
