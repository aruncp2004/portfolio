import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import { projects } from '../../data/projects';
import ProjectCard from '../shared/ProjectCard';
import SectionHeader from '../shared/SectionHeader';
import { useScrollReveal } from '../../hooks/useScrollReveal';

export default function SelectedWork() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section className="section-pad" id="work">
      <div className="max-w-6xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4 mb-14">
            <SectionHeader
              eyebrow="Selected Work"
              title="Projects & Concepts"
              subtitle="A mix of website concepts and professional experience in healthcare and business web development."
            />
            <Link
              to="/work"
              className="shrink-0 flex items-center gap-2 text-sm font-semibold text-teal-400 hover:text-teal-300 transition-colors self-start sm:self-auto mb-14"
            >
              View all work <ArrowRight size={15} />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-6">
            {projects.slice(0, 4).map((project, i) => (
              <ProjectCard key={project.id} project={project} index={i} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
