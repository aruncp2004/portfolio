import { Link } from 'react-router-dom';
import { ArrowRight, Play } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background orbs */}
      <div className="absolute inset-0 pointer-events-none">
        <div
          className="absolute top-1/4 left-1/4 w-[500px] h-[500px] rounded-full animate-orb"
          style={{
            background: 'radial-gradient(circle, rgba(0,212,200,0.12) 0%, transparent 70%)',
            filter: 'blur(40px)',
          }}
        />
        <div
          className="absolute bottom-1/3 right-1/4 w-[400px] h-[400px] rounded-full animate-orb-reverse"
          style={{
            background: 'radial-gradient(circle, rgba(124,111,255,0.12) 0%, transparent 70%)',
            filter: 'blur(40px)',
          }}
        />
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(0,212,200,0.05) 0%, transparent 70%)',
            filter: 'blur(60px)',
          }}
        />
      </div>

      {/* Grid overlay */}
      <div
        className="absolute inset-0 opacity-[0.025] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.8) 1px, transparent 1px),
                            linear-gradient(90deg, rgba(255,255,255,0.8) 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }}
      />

      <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
        {/* Eyebrow */}
        <div className="animate-fade-up opacity-0-start inline-flex items-center gap-2 glass rounded-full px-4 py-2 mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-teal-400 animate-glow" />
          <span className="text-xs font-semibold text-white/60 tracking-widest uppercase">
            Available for new projects
          </span>
        </div>

        {/* Headline */}
        <h1 className="animate-fade-up opacity-0-start delay-100 font-display font-bold text-4xl sm:text-5xl md:text-6xl lg:text-7xl leading-[1.05] tracking-tight mb-6">
          <span className="text-white">Modern Websites for</span>
          <br />
          <span className="gradient-text-warm">Clinics & Healthcare</span>
          <br />
          <span className="text-white">Businesses</span>
        </h1>

        {/* Supporting text */}
        <p className="animate-fade-up opacity-0-start delay-200 text-white/50 text-lg md:text-xl leading-relaxed max-w-2xl mx-auto mb-10">
          Professional, responsive websites designed to help healthcare businesses build trust,
          showcase their services and make it easier for patients to contact them.
        </p>

        {/* CTAs */}
        <div className="animate-fade-up opacity-0-start delay-300 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link to="/contact" className="btn-primary text-base px-7 py-3.5">
            <span>Get a Free Website Demo</span>
            <ArrowRight size={18} />
          </Link>
          <Link to="/work" className="btn-ghost text-base px-7 py-3.5">
            <Play size={16} />
            View My Work
          </Link>
        </div>

        {/* Social proof strip */}
        <div className="animate-fade-up opacity-0-start delay-400 mt-16 flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-12">
          {[
            { value: '4+', label: 'Projects Delivered' },
            { value: '100%', label: 'Mobile Responsive' },
            { value: 'Chennai', label: 'Based In' },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="font-display font-bold text-2xl gradient-text">{stat.value}</p>
              <p className="text-xs text-white/35 mt-1 uppercase tracking-wider">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom fade */}
      <div
        className="absolute bottom-0 left-0 right-0 h-32 pointer-events-none"
        style={{ background: 'linear-gradient(to top, #0a0a0f, transparent)' }}
      />
    </section>
  );
}
