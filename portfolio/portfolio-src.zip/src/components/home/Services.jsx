import { Monitor, CalendarCheck, MessageCircle, Search, Zap } from 'lucide-react';
import SectionHeader from '../shared/SectionHeader';
import { useScrollReveal } from '../../hooks/useScrollReveal';

const services = [
  {
    icon: Monitor,
    title: 'Clinic Website',
    description:
      'A modern, responsive website built around your clinic — your services, your team, your brand. Designed to work beautifully on every device.',
  },
  {
    icon: CalendarCheck,
    title: 'Appointment & Contact',
    description:
      'Clear, simple flows that guide patients from browsing to booking. Forms, click-to-call and WhatsApp — all set up and working.',
  },
  {
    icon: MessageCircle,
    title: 'WhatsApp Integration',
    description:
      "A floating WhatsApp button means patients can reach you with one tap — on every page of your website, day or night.",
  },
  {
    icon: Search,
    title: 'Google & SEO Setup',
    description:
      'Basic technical SEO, Google Search Console setup and site speed optimisation so your clinic can be found in local searches.',
  },
  {
    icon: Zap,
    title: 'Website Automation',
    description:
      'Connect your enquiry forms to email and Google Sheets so every lead is captured and organised automatically.',
  },
];

export default function Services() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section className="section-pad">
      <div className="max-w-6xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <SectionHeader
            eyebrow="What I Offer"
            title="Services"
            subtitle="Everything a clinic or healthcare business needs to establish a credible, patient-friendly online presence."
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {services.map((s, i) => {
              const Icon = s.icon;
              return (
                <div
                  key={i}
                  className="glass glass-hover rounded-2xl p-7 group"
                  style={{ transitionDelay: `${i * 60}ms` }}
                >
                  <div className="w-12 h-12 rounded-xl bg-teal-400/10 border border-teal-400/20 flex items-center justify-center mb-5 group-hover:bg-teal-400/15 transition-colors">
                    <Icon size={22} className="text-teal-400" />
                  </div>
                  <h3 className="font-display font-semibold text-white text-base mb-2.5">
                    {s.title}
                  </h3>
                  <p className="text-sm text-white/45 leading-relaxed">{s.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
