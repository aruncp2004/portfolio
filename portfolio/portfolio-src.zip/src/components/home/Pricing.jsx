import { Link } from 'react-router-dom';
import { Check, ArrowRight } from 'lucide-react';
import SectionHeader from '../shared/SectionHeader';
import { useScrollReveal } from '../../hooks/useScrollReveal';

const included = [
  'Custom design tailored to your clinic',
  'Mobile-first, fully responsive build',
  'WhatsApp & contact integration',
  'Google & basic SEO setup',
  'Fast-loading, modern codebase',
  'Post-launch support',
];

export default function Pricing() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section className="section-pad">
      <div className="max-w-6xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <SectionHeader
            eyebrow="Investment"
            title="Website Packages"
            subtitle="Transparent starting prices. Final cost depends on your specific requirements."
            center
          />

          <div className="max-w-lg mx-auto">
            <div
              className="relative rounded-3xl p-8 md:p-10 overflow-hidden"
              style={{
                background:
                  'linear-gradient(135deg, rgba(0,212,200,0.08) 0%, rgba(124,111,255,0.08) 100%)',
                border: '1px solid rgba(0,212,200,0.2)',
              }}
            >
              {/* Glow */}
              <div
                className="absolute -top-20 -right-20 w-48 h-48 rounded-full pointer-events-none"
                style={{
                  background: 'radial-gradient(circle, rgba(0,212,200,0.15) 0%, transparent 70%)',
                  filter: 'blur(30px)',
                }}
              />

              <div className="relative z-10">
                <p className="text-xs font-semibold text-teal-400 uppercase tracking-widest mb-2">
                  Starting From
                </p>
                <div className="flex items-end gap-2 mb-1">
                  <span className="font-display font-bold text-5xl text-white">₹8,999</span>
                </div>
                <p className="text-sm text-white/40 mb-8">
                  Exact pricing depends on your requirements — contact me for a tailored quote.
                </p>

                <ul className="space-y-3 mb-8">
                  {included.map((item) => (
                    <li key={item} className="flex items-center gap-3 text-sm text-white/60">
                      <div className="shrink-0 w-5 h-5 rounded-full bg-teal-400/15 border border-teal-400/25 flex items-center justify-center">
                        <Check size={11} className="text-teal-400" />
                      </div>
                      {item}
                    </li>
                  ))}
                </ul>

                <Link to="/contact" className="btn-primary w-full justify-center text-base py-3.5">
                  <span>Get a Free Website Demo</span>
                  <ArrowRight size={18} />
                </Link>
              </div>
            </div>

            <p className="text-center text-xs text-white/25 mt-5">
              No commitment required. Free demo created before any payment.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
