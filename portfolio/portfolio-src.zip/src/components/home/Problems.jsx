import { Globe, Layout, MessageSquare, Smartphone, Star } from 'lucide-react';
import SectionHeader from '../shared/SectionHeader';
import { useScrollReveal } from '../../hooks/useScrollReveal';

const problems = [
  {
    icon: Globe,
    title: 'No Professional Online Presence',
    description:
      'Many clinics are found only through Google Maps or social media. A dedicated website creates a lasting, professional digital home.',
    accent: '#00d4c8',
  },
  {
    icon: Layout,
    title: "Patients Can't Easily Understand Services",
    description:
      'A well-structured website clearly presents treatments and services, helping patients decide with confidence before they even call.',
    accent: '#7c6fff',
  },
  {
    icon: MessageSquare,
    title: 'Difficult Appointment Enquiries',
    description:
      'WhatsApp buttons, contact forms and click-to-call make it simple for patients to reach out at any point in their visit.',
    accent: '#00d4c8',
  },
  {
    icon: Smartphone,
    title: 'Poor Mobile Experience',
    description:
      'Most patients browse from their phones. A mobile-first website ensures they have a smooth experience on any device.',
    accent: '#7c6fff',
  },
  {
    icon: Star,
    title: 'Weak First Impression',
    description:
      'A professional, modern website immediately communicates quality and builds trust before a patient steps through the door.',
    accent: '#00d4c8',
  },
];

export default function Problems() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section className="section-pad">
      <div className="max-w-6xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <SectionHeader
            eyebrow="Why It Matters"
            title="Problems We Help Solve"
            subtitle="Healthcare businesses face specific digital challenges. Here's how a professional website addresses them."
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {problems.map((p, i) => {
              const Icon = p.icon;
              return (
                <div
                  key={i}
                  className="glass glass-hover rounded-2xl p-6"
                  style={{ transitionDelay: `${i * 60}ms` }}
                >
                  <div
                    className="w-11 h-11 rounded-xl flex items-center justify-center mb-4"
                    style={{ background: `${p.accent}15`, border: `1px solid ${p.accent}25` }}
                  >
                    <Icon size={20} style={{ color: p.accent }} />
                  </div>
                  <h3 className="font-display font-semibold text-white text-base mb-2">
                    {p.title}
                  </h3>
                  <p className="text-sm text-white/45 leading-relaxed">{p.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
