import { Briefcase } from 'lucide-react';
import SectionHeader from '../shared/SectionHeader';
import { useScrollReveal } from '../../hooks/useScrollReveal';

export default function Experience() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section className="section-pad">
      <div className="max-w-6xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <SectionHeader
            eyebrow="Background"
            title="Professional Experience"
          />

          <div className="glass rounded-2xl p-7 md:p-10 flex flex-col md:flex-row gap-8">
            <div className="shrink-0 w-14 h-14 rounded-2xl bg-amber-400/10 border border-amber-400/20 flex items-center justify-center">
              <Briefcase size={24} className="text-amber-400" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-3 mb-3">
                <h3 className="font-display font-bold text-white text-lg">
                  Professional Web Development Experience
                </h3>
                <span className="badge badge-experience">Professional Experience</span>
              </div>
              <p className="text-white/50 text-sm leading-relaxed mb-5 max-w-2xl">
                Developed and deployed responsive business websites and digital solutions as part of
                my professional experience. This work involved full-stack web development, analytics
                integration, performance optimisation and ongoing maintenance for real business
                environments.
              </p>
              <div className="flex flex-wrap gap-2">
                {['React', 'HTML/CSS/JS', 'Google Analytics', 'SEO', 'Performance Optimisation', 'Responsive Design'].map(
                  (skill) => (
                    <span
                      key={skill}
                      className="text-xs px-3 py-1.5 rounded-full bg-white/[0.05] text-white/40 border border-white/[0.06]"
                    >
                      {skill}
                    </span>
                  )
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
