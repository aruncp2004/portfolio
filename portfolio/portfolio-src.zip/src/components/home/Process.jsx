import SectionHeader from '../shared/SectionHeader';
import { useScrollReveal } from '../../hooks/useScrollReveal';

const steps = [
  {
    num: '01',
    title: 'Understand',
    description:
      'We talk through your clinic, the services you offer, your patients and what you need the website to do.',
  },
  {
    num: '02',
    title: 'Design',
    description:
      'I create the visual direction and a working website concept tailored to your clinic, for your review.',
  },
  {
    num: '03',
    title: 'Develop',
    description:
      'The full responsive website is built — mobile-first, fast and ready for real patients.',
  },
  {
    num: '04',
    title: 'Review',
    description:
      'You review the website, we go through feedback together and refine until it feels right.',
  },
  {
    num: '05',
    title: 'Launch',
    description:
      'The website goes live. I handle the deployment, domain configuration and initial setup.',
  },
];

export default function Process() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section className="section-pad">
      <div className="max-w-6xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          <SectionHeader
            eyebrow="How It Works"
            title="The Process"
            subtitle="A clear, structured approach so you always know where things stand."
            center
          />

          {/* Timeline */}
          <div className="relative">
            {/* Connector line — desktop */}
            <div
              className="hidden lg:block absolute top-10 left-0 right-0 h-px"
              style={{
                background:
                  'linear-gradient(90deg, transparent, rgba(0,212,200,0.2) 10%, rgba(0,212,200,0.2) 90%, transparent)',
              }}
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
              {steps.map((step, i) => (
                <div key={i} className="relative flex flex-col items-center text-center lg:items-start lg:text-left">
                  {/* Number bubble */}
                  <div className="relative z-10 w-20 h-20 lg:w-16 lg:h-16 rounded-2xl lg:rounded-xl glass-strong flex flex-col items-center justify-center mb-5 border border-teal-400/20 shrink-0">
                    <span className="text-xs text-teal-400/60 font-mono font-medium">{step.num}</span>
                  </div>
                  <h3 className="font-display font-bold text-white text-base mb-2">{step.title}</h3>
                  <p className="text-sm text-white/40 leading-relaxed">{step.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
