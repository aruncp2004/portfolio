import { Heart, Palette, Smartphone, Gauge, MessageSquare, Gift } from 'lucide-react';
import SectionHeader from '../shared/SectionHeader';
import { useScrollReveal } from '../../hooks/useScrollReveal';

const reasons = [
  {
    icon: Heart,
    title: 'Healthcare-Focused',
    description: 'I build specifically for clinics and healthcare businesses — not generic templates adapted to fit.',
  },
  {
    icon: Palette,
    title: 'Custom Design',
    description: "Every website is designed from scratch around your clinic's identity, services and patients.",
  },
  {
    icon: Smartphone,
    title: 'Mobile-First',
    description: 'Designed for phones first, then scaled up — because most patients browse on mobile.',
  },
  {
    icon: Gauge,
    title: 'Performance Focused',
    description: 'Fast-loading, technically clean websites built with modern tools and best practices.',
  },
  {
    icon: MessageSquare,
    title: 'Direct Communication',
    description: 'You work directly with me — no agency overhead, no account managers in between.',
  },
  {
    icon: Gift,
    title: 'Free Demo First',
    description: 'I create a personalised website demo for your clinic before any commitment is made.',
  },
];

export default function WhyMe() {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section className="section-pad">
      <div className="max-w-6xl mx-auto px-6">
        <div
          ref={ref}
          className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          {/* Glass card wrapper */}
          <div className="glass rounded-3xl p-8 md:p-12">
            <SectionHeader
              eyebrow="Why Work With Me"
              title="What Makes This Different"
              subtitle="A focused, honest approach to building websites for healthcare — without the agency complexity."
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {reasons.map((r, i) => {
                const Icon = r.icon;
                return (
                  <div key={i} className="flex gap-4">
                    <div className="shrink-0 w-9 h-9 rounded-lg bg-teal-400/10 border border-teal-400/15 flex items-center justify-center mt-0.5">
                      <Icon size={17} className="text-teal-400" />
                    </div>
                    <div>
                      <h3 className="font-display font-semibold text-white text-sm mb-1">{r.title}</h3>
                      <p className="text-sm text-white/45 leading-relaxed">{r.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
