import { Link } from 'react-router-dom';
import { MessageCircle, Mail, Phone } from 'lucide-react';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-white/[0.06] pt-16 pb-8">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <div>
            <Link to="/" className="font-display font-bold text-xl text-white">
              Arun<span className="gradient-text">Kumar</span>
            </Link>
            <p className="mt-3 text-sm text-white/45 leading-relaxed max-w-xs">
              Modern websites for clinics and healthcare businesses. Chennai, India.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <p className="text-xs font-semibold text-white/30 uppercase tracking-widest mb-4">Navigation</p>
            <ul className="space-y-2.5">
              {[
                { label: 'Home', to: '/' },
                { label: 'Work', to: '/work' },
                { label: 'About', to: '/about' },
                { label: 'Contact', to: '/contact' },
              ].map((l) => (
                <li key={l.to}>
                  <Link to={l.to} className="text-sm text-white/50 hover:text-teal-400 transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <p className="text-xs font-semibold text-white/30 uppercase tracking-widest mb-4">Contact</p>
            <ul className="space-y-3">
              <li>
                <a
                  href="https://wa.me/919498096306"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2.5 text-sm text-white/50 hover:text-teal-400 transition-colors"
                >
                  <MessageCircle size={15} />
                  WhatsApp
                </a>
              </li>
              <li>
                <a
                  href="tel:+919498096306"
                  className="flex items-center gap-2.5 text-sm text-white/50 hover:text-teal-400 transition-colors"
                >
                  <Phone size={15} />
                  +91 94980 96306
                </a>
              </li>
              <li>
                <a
                  href="mailto:hello@arunkumar.dev"
                  className="flex items-center gap-2.5 text-sm text-white/50 hover:text-teal-400 transition-colors"
                >
                  <Mail size={15} />
                  hello@arunkumar.dev
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="gradient-divider mb-6" />

        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-white/25">
          <p>© {year} Arun Kumar. All rights reserved.</p>
          <p>Chennai, India</p>
        </div>
      </div>
    </footer>
  );
}
