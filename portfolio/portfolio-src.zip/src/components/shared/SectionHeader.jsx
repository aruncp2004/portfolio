export default function SectionHeader({ eyebrow, title, subtitle, center = false }) {
  return (
    <div className={`mb-14 ${center ? 'text-center' : ''}`}>
      {eyebrow && (
        <p className="text-xs font-semibold text-teal-400 uppercase tracking-widest mb-3">
          {eyebrow}
        </p>
      )}
      <h2 className="font-display font-bold text-3xl md:text-4xl text-white leading-tight">
        {title}
      </h2>
      {subtitle && (
        <p className={`mt-4 text-white/50 text-base leading-relaxed ${center ? 'max-w-xl mx-auto' : 'max-w-xl'}`}>
          {subtitle}
        </p>
      )}
    </div>
  );
}
