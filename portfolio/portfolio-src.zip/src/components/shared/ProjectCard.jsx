import { ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getClassificationLabel, getClassificationClass } from '../../data/projects';

export default function ProjectCard({ project, index = 0 }) {
  const { id, title, category, classification, description, tags, gradient, accent } = project;

  return (
    <div
      className="glass glass-hover rounded-2xl overflow-hidden group"
      style={{ animationDelay: `${index * 0.1}s` }}
    >
      {/* Visual placeholder */}
      <div className={`relative h-52 bg-gradient-to-br ${gradient} flex items-center justify-center overflow-hidden`}>
        {/* Abstract pattern */}
        <div
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: `radial-gradient(circle at 30% 40%, ${accent}40 0%, transparent 60%),
                              radial-gradient(circle at 70% 70%, ${accent}20 0%, transparent 50%)`,
          }}
        />
        <div
          className="absolute top-6 right-6 w-24 h-24 rounded-full opacity-20 animate-orb"
          style={{ background: `radial-gradient(circle, ${accent}, transparent)` }}
        />
        <div
          className="absolute bottom-4 left-8 w-16 h-16 rounded-full opacity-15 animate-orb-reverse"
          style={{ background: `radial-gradient(circle, ${accent}, transparent)` }}
        />
        {/* Grid lines for depth */}
        <div
          className="absolute inset-0 opacity-[0.06]"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)`,
            backgroundSize: '32px 32px',
          }}
        />
        {/* Category label */}
        <span
          className="relative z-10 font-display font-semibold text-sm px-4 py-2 rounded-full glass"
          style={{ color: accent, borderColor: `${accent}30` }}
        >
          {category}
        </span>
      </div>

      {/* Content */}
      <div className="p-6">
        <div className="flex items-start justify-between gap-3 mb-3">
          <h3 className="font-display font-bold text-lg text-white group-hover:text-teal-400 transition-colors">
            {title}
          </h3>
          <span className={`badge ${getClassificationClass(classification)} shrink-0`}>
            {getClassificationLabel(classification)}
          </span>
        </div>

        <p className="text-sm text-white/50 leading-relaxed mb-4">{description}</p>

        <div className="flex items-center justify-between">
          <div className="flex flex-wrap gap-1.5">
            {tags.map((tag) => (
              <span
                key={tag}
                className="text-xs px-2.5 py-1 rounded-full bg-white/[0.05] text-white/40 border border-white/[0.06]"
              >
                {tag}
              </span>
            ))}
          </div>
          <Link
            to={`/work/${id}`}
            className="shrink-0 ml-3 w-9 h-9 rounded-full glass flex items-center justify-center text-white/40 hover:text-teal-400 hover:border-teal-400/30 transition-all"
            aria-label={`View ${title}`}
          >
            <ArrowUpRight size={16} />
          </Link>
        </div>
      </div>
    </div>
  );
}
