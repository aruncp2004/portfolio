export const projects = [
  {
    id: 1,
    title: 'BrightSmile Dental',
    category: 'Healthcare / Dental',
    classification: 'concept',
    description:
      'A modern dental clinic website focused on treatment discovery, appointment enquiries and building patient trust through clean design.',
    tags: ['React', 'Responsive', 'WhatsApp CTA'],
    gradient: 'from-teal-500/20 via-cyan-400/10 to-blue-600/20',
    accent: '#00d4c8',
  },
  {
    id: 2,
    title: 'DermaCare Clinic',
    category: 'Healthcare / Dermatology',
    classification: 'concept',
    description:
      'A dermatology clinic website concept showcasing skin treatments, doctor profiles and a clean mobile-first patient experience.',
    tags: ['React', 'Mobile-first', 'SEO Ready'],
    gradient: 'from-violet-500/20 via-purple-400/10 to-pink-600/20',
    accent: '#7c6fff',
  },
  {
    id: 3,
    title: 'MediPoint Health',
    category: 'Healthcare / General',
    classification: 'concept',
    description:
      'A multi-specialty healthcare clinic website with department listings, doctor discovery and patient enquiry flows.',
    tags: ['React', 'Multi-page', 'Contact Form'],
    gradient: 'from-blue-500/20 via-indigo-400/10 to-violet-600/20',
    accent: '#6366f1',
  },
  {
    id: 4,
    title: 'Velciti Consulting Engineers',
    category: 'Engineering / B2B',
    classification: 'experience',
    description:
      'Developed and maintained a responsive business website for a geotechnical engineering consulting firm as part of professional experience.',
    tags: ['HTML/CSS/JS', 'cPanel', 'Analytics'],
    gradient: 'from-amber-500/20 via-orange-400/10 to-yellow-600/20',
    accent: '#f5c542',
  },
];

export const getClassificationLabel = (type) => {
  const map = {
    concept: 'Website Concept',
    client: 'Client Project',
    experience: 'Professional Experience',
  };
  return map[type] || type;
};

export const getClassificationClass = (type) => {
  const map = {
    concept: 'badge-concept',
    client: 'badge-client',
    experience: 'badge-experience',
  };
  return map[type] || 'badge-concept';
};
