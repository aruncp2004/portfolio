/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        teal: { 400: '#00d4c8', 500: '#00bdb7', 600: '#009e99' },
        violet: { 400: '#9d8fff', 500: '#7c6fff', 600: '#5a4de8' },
        ink: {
          50: '#f5f5f4', 100: '#e8e8e6', 200: '#d1d1ce',
          400: '#7e7d79', 600: '#48473f', 800: '#1e1e1c', 900: '#111110',
        },
      },
      fontFamily: {
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
        display: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
      },
      screens: {
        xs: '390px',
      },
    },
  },
  plugins: [],
}
